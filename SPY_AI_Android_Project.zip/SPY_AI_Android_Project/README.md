# SPY AI Android starter

This is a starter Android project that packages a mobile-first SPY AI interface into an APK.
It is a functional UI demo, not a fully connected AI assistant: chat replies are demo messages,
and image generation, AI coding, automatic research, and voice AI are not integrated yet.

## Build an APK using GitHub Actions from an Android phone

1. Sign in to https://github.com/ and create a new repository named `SPY-AI`.
2. Upload the files and folders from this project ZIP to the repository's main branch. Keep the `.github/workflows/build-apk.yml` path intact.
3. Open the repository's **Actions** tab and select **Build SPY AI APK**.
4. Tap **Run workflow** if it has not started automatically.
5. Wait for the workflow to finish successfully.
6. Open the completed workflow run and download the `SPY-AI-debug-APK` artifact. GitHub may ask you to sign in.
7. Extract the downloaded artifact ZIP to obtain `app-debug.apk`, then open it on your Android phone and approve installation if Android asks.

The APK is a debug build for testing. Do not distribute it as a trusted production app without reviewing and signing a release build.

## Requirements and safety

- Build needs internet access in GitHub Actions to download Gradle and Android SDK components.
- No API keys are included.
- Do not place private AI API keys in `index.html` or other client-side files.
- Before connecting AI services, use a secure backend or a supported Firebase AI Logic integration and configure quotas/security rules.
- Security tools should be used only on systems you own or are explicitly authorized to test.
